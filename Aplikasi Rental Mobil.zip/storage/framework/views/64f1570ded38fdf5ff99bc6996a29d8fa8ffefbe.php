
<?php $__env->startSection('content'); ?>
<br>
<form action="/mobil/<?php echo e($data->id); ?>/update" method="POST">
<?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="exampleFormControlInput1">Kode Mobil</label>
    <input type="text" value="<?php echo e($data->kode_mobil); ?>" class="form-control" name="kode_mobil" required>
  </div>
  <div class="form-group">
    <label for="exampleFormControlInput1">Merek Mobil</label>
    <input type="text" class="form-control" value="<?php echo e($data->merek_mobil); ?>" name="merek_mobil" required>
  </div>
  <div class="form-group">
    <label for="exampleFormControlInput1">No Polisi</label>
    <input type="text" class="form-control" value="<?php echo e($data->no_pol); ?>" name="no_pol" required>
  </div>
  <div class="form-group">
    <label for="exampleFormControlInput1">Tahun Sewa</label>
    <input type="number" value="<?php echo e($data->tahun_sewa); ?>" class="form-control" name="tahun_sewa" required>
  </div>
  <div class="form-group">
    <label for="exampleFormControlInput1">Harga Sewa</label>
    <input type="number" value="<?php echo e($data->harga_sewa); ?>" class="form-control" name="harga_sewa" required>
  </div>
  <div class="form-group">
    <button type="submit" class="btn btn-primary">Simpan</button>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LSP DTS\LSP\resources\views/mobil/edit.blade.php ENDPATH**/ ?>