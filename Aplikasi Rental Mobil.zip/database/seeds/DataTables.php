<?php

use Illuminate\Database\Seeder;

class DataTables extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        
    }
}
